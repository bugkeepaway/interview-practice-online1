#!/bin/bash
echo "========================================"
echo "  AI 面试对练系统 - 启动器 (Mac/Linux)"
echo "========================================"

cd "$(dirname "$0")"

echo "[1/2] 安装依赖..."
npm install

echo
echo "[2/2] 启动服务器..."
echo "本机访问: http://localhost:3000"
echo

node server.js &
SERVER_PID=$!

sleep 2

echo "正在安装内网穿透工具..."
npm install -g localtunnel 2>/dev/null

echo
echo "========================================"
echo "正在创建公网链接..."
echo "========================================"
lt --port 3000 --subdomain interview-practice
