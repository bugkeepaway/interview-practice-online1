@echo off
setlocal enabledelayedexpansion

echo ========================================
echo   AI 面试对练系统 - 一键启动
echo ========================================
echo.

cd /d "%~dp0"

echo [1/3] 安装依赖...
call npm install
if errorlevel 1 (
    echo 安装失败，请重试
    pause
    exit /b 1
)

echo.
echo [2/3] 启动本地服务器...
start /b node server.js > server.log 2>&1

echo 等待服务器启动...
timeout /t 3 /nobreak >nul

echo.
echo [3/3] 创建公网链接...
echo.

:: 获取本机IP
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    set "ip=%%a"
    set "ip=!ip: =!"
)
if not defined ip set "ip=localhost"

echo ========================================
echo   启动成功！
echo ========================================
echo.
echo 本机访问:     http://localhost:3000
echo 局域网访问:   http://!ip!:3000
echo.

:: 打开浏览器
start http://localhost:3000

echo 正在创建公网链接（首次可能需要30秒）...
echo 此链接可分享给其他人直接访问
echo.

:: 使用localtunnel创建公网链接
npx lt --port 3000

pause
