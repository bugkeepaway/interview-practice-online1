@echo off
echo ========================================
echo   AI 面试对练系统 - 启动器
echo ========================================
echo.

cd /d "%~dp0"

echo [1/2] 安装依赖...
call npm install 2>nul

echo.
echo [2/2] 启动服务器...
echo.
echo 启动后等待几秒会自动打开浏览器
echo.

start /b node server.js > server.log 2>&1

timeout /t 3 /nobreak >nul

echo 请复制以下地址分享给考生:
echo.

for /f "tokens=1" %%a in ('powershell -Command "(Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.InterfaceAlias -notlike '*Loopback*' -and $_.IPAddress -notlike '127.*'}).IPAddress[0]"') do set LOCALIP=%%a

echo ========================================
echo 本机访问: http://localhost:3000
echo 局域网访问: http://%LOCALIP%:3000
echo ========================================

start http://localhost:3000

echo.
echo 等待服务器完全启动...
timeout /t 2 /nobreak >nul

echo.
echo 正在安装内网穿透工具...
npm install -g localtunnel 2>nul

echo.
echo ========================================
echo 正在创建公网链接（首次可能较慢）...
echo ========================================
lt --port 3000 --subdomain interview-practice
