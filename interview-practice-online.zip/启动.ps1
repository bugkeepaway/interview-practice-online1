$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AI 面试对练系统 - 启动中" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$projectPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectPath

Write-Host "[1/2] 检查依赖..." -ForegroundColor Yellow
if (-not (Test-Path "node_modules")) {
    Write-Host "正在安装依赖..." -ForegroundColor Yellow
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "安装失败！" -ForegroundColor Red
        Read-Host "按回车退出"
        exit 1
    }
}

Write-Host "[2/2] 启动服务器..." -ForegroundColor Yellow

# 获取本机IP
$localIP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { 
    $_.InterfaceAlias -notlike "*Loopback*" -and $_.IPAddress -notlike "127.*" 
} | Select-Object -First 1).IPAddress

if (-not $localIP) { $localIP = "localhost" }

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  启动成功！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "本机访问:   http://localhost:3000" -ForegroundColor Cyan
Write-Host "局域网:     http://$localIP`:3000" -ForegroundColor Cyan
Write-Host ""

# 打开浏览器
Start-Process "http://localhost:3000"

# 启动服务器
node server.js
